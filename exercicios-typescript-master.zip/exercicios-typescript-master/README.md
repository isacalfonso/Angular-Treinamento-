# Exercícios de Typescript
Exercícios de Typescript do Módulo Conhecendo a Linguagem de Programação JavaScript, Bootcamp Geração Tech Unimed-BH em parceria com a [Digital Innovation One](https://www.dio.me/).
